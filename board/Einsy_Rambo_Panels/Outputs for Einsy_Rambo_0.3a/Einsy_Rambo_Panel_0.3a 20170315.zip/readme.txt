Readme File for Printed Circuit Board 'Einsy_Rambo_0.3a'

Board Specification
Part Number            Einsy_Rambo
Revision               0.3a
Board size             105 x 71mm
Board Thickness        1.524mm (0.06")
Board type             Rigid
Number of layers       4
P.C.B material         RoHS TG170
Finished Copper        2oz, 1oz (See Stackup)
Finish                 ENIG (Gold) (Lead free) (RoHS)
Mask type              LPI 
Mask color             Matte Black
Silk screen color      Orange
Silk screen Sides      BOTH 
Min trace width        0.007"
Min clearance          0.007"
Min Hole Diameter >=   10mil
Gold Edge Connectors   No
Internal slots/routes  0
Blind Vias             No
Buried Vias            No
No of Boards/Panel     3
Routing                V-Score
Panel Size     116.8 X 226.1mm

Drill format           Leading zero suppression 2.4

Special Requirements
1. Fabricate PCB in accordiance with IPC-A-600 CLASS 2 (LATEST REVISION)
2. The PCB must be lead free assembly process compatible.
  Must handle minimum 6 cycles - 260C for 10 seconds.
3. Please ship panels including rails with tooling holes and fiducials in gerber files.
4.UL LOGO + ID and ROHS logo to be placed on solder side (bottom silk screen) by board fab in regions .

Critical Tolerances: None

Layer Description
(Note: Inner layers are counted from the top downwards)
Top Paste                     Einsy_Rambo_Panel.GTP
Top Silk Screen               Einsy_Rambo_Panel.GTO
Top Solder Mask               Einsy_Rambo_Panel.GTS
Top Copper                    Einsy_Rambo_Panel.GTL
Inner Plane 1                 Einsy_Rambo_Panel.GP1
Inner Plane 2                 Einsy_Rambo_Panel.GP2
Inner Signal 1                Einsy_Rambo_Panel.G1
Inner Plane 3                 Einsy_Rambo_Panel.GP3
Bottom Copper                 Einsy_Rambo_Panel.GBL
Bottom Solder Mask            Einsy_Rambo_Panel.GBS
Bottom Silk Screen            Einsy_Rambo_Panel.GBO
NC Drill File                 Einsy_Rambo_Panel.TXT
Board Dimensions              Einsy_Rambo_Panel.GM8
Panel Dimensions              Einsy_Rambo_Panel.GM30
Board Outline	     		  Einsy_Rambo_Panel.GM1
Fabrication Notes             Einsy_Rambo_Panel.GM2
V-Score                       Einsy_Rambo_Panel.GM31
Panel Outline                 Einsy_Rambo_Panel.GM32
IPC-D-356 Netlist             Einsy_Rambo_Panel IPC-D-356.net

Contact Information
Address
Company        UltiMachine
Address        200 12th St. N.
City           South Pittsburg
State          TN
PostCode       37380
Country        USA
Email          info@ultimachine.com
Phone          423-228-0005

Purchasing contact:
Lee Turner - lee@ultimachine.com

Technical contacts:
Aaron Shepard - aaron@ultimachine.com 
Johnny Russell - johnny@ultimachine.com


Please quote quantities / lead time:
32 pcs = 16 panels / 2 weeks
106 pcs = 53 panels
510 pcs = 255 panels
1020 pcs = 510 panels